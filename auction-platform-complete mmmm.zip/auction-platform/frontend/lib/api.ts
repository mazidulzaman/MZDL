import axios from 'axios'

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
})

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response) {
      // Server responded with error
      console.error('API Error:', error.response.data)
      return Promise.reject(error.response.data)
    } else if (error.request) {
      // No response received
      console.error('Network Error:', error.request)
      return Promise.reject({ error: 'Network error. Please check your connection.' })
    } else {
      // Request setup error
      console.error('Request Error:', error.message)
      return Promise.reject({ error: error.message })
    }
  }
)

export const auctionApi = {
  // Auction endpoints
  getAuctions: () => api.get('/api/auctions'),

  getAuction: (id: string) => api.get(`/api/auctions/${id}`),

  placeBid: (auctionId: string, data: { amount: number; userId: string }) =>
    api.post(`/api/auctions/${auctionId}/bid`, data),

  createAuction: (data: any) => api.post('/api/auctions', data),

  updateAuction: (id: string, data: any) => api.put(`/api/auctions/${id}`, data),

  deleteAuction: (id: string) => api.delete(`/api/auctions/${id}`),

  // User endpoints
  register: (data: any) => api.post('/api/auth/register', data),

  login: (data: any) => api.post('/api/auth/login', data),

  getProfile: () => api.get('/api/users/profile'),

  updateProfile: (data: any) => api.put('/api/users/profile', data),

  // Product endpoints (fixed price)
  getProducts: () => api.get('/api/products'),

  getProduct: (id: string) => api.get(`/api/products/${id}`),

  createProduct: (data: any) => api.post('/api/products', data),

  // Order endpoints
  createOrder: (data: any) => api.post('/api/orders', data),

  getOrders: () => api.get('/api/orders'),

  getOrder: (id: string) => api.get(`/api/orders/${id}`),

  // Category endpoints
  getCategories: () => api.get('/api/categories'),

  // Utility endpoints
  uploadImage: (file: File) => {
    const formData = new FormData()
    formData.append('image', file)
    return api.post('/api/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },
}

export default api
