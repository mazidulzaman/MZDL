import { io, Socket } from 'socket.io-client'

class SocketService {
  private socket: Socket | null = null
  private static instance: SocketService

  private constructor() {}

  public static getInstance(): SocketService {
    if (!SocketService.instance) {
      SocketService.instance = new SocketService()
    }
    return SocketService.instance
  }

  public connect(): Socket {
    if (!this.socket) {
      const serverUrl = process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:5000'
      this.socket = io(serverUrl, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
        timeout: 20000
      })

      this.setupEventListeners()
    }
    return this.socket
  }

  private setupEventListeners(): void {
    if (!this.socket) return

    this.socket.on('connect', () => {
      console.log('✅ Connected to WebSocket server')
    })

    this.socket.on('disconnect', (reason) => {
      console.log('❌ Disconnected from WebSocket server:', reason)
    })

    this.socket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error)
    })

    this.socket.on('reconnect', (attemptNumber) => {
      console.log(`🔁 Reconnected after ${attemptNumber} attempts`)
    })
  }

  public joinAuction(auctionId: string): void {
    if (this.socket && this.socket.connected) {
      this.socket.emit('join-auction', auctionId)
    }
  }

  public leaveAuction(auctionId: string): void {
    if (this.socket && this.socket.connected) {
      this.socket.emit('leave-auction', auctionId)
    }
  }

  public placeBid(auctionId: string, userId: string, amount: number): void {
    if (this.socket && this.socket.connected) {
      this.socket.emit('place-bid', { auctionId, userId, amount })
    }
  }

  public onNewBid(callback: (bid: any) => void): void {
    if (this.socket) {
      this.socket.on('new-bid', callback)
    }
  }

  public onBidUpdate(callback: (update: any) => void): void {
    if (this.socket) {
      this.socket.on('bid-update', callback)
    }
  }

  public onBidError(callback: (error: any) => void): void {
    if (this.socket) {
      this.socket.on('bid-error', callback)
    }
  }

  public onAuctionState(callback: (state: any) => void): void {
    if (this.socket) {
      this.socket.on('auction-state', callback)
    }
  }

  public onAuctionEnded(callback: (data: any) => void): void {
    if (this.socket) {
      this.socket.on('auction-ended', callback)
    }
  }

  public off(event: string, callback?: any): void {
    if (this.socket) {
      this.socket.off(event, callback)
    }
  }

  public disconnect(): void {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }
  }

  public isConnected(): boolean {
    return this.socket?.connected || false
  }

  public getSocket(): Socket | null {
    return this.socket
  }
}

export const socketService = SocketService.getInstance()
