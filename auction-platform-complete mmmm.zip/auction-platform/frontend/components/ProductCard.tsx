\'use client\';

import { Star, ShoppingCart, Heart } from 'lucide-react'
import { useState } from 'react'
import Image from 'next/image'

interface ProductCardProps {
  product: {
    id: string
    title: string
    price: number
    rating: number
    reviews: number
    imageUrl: string
    category: string
  }
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [isLiked, setIsLiked] = useState(false)
  const [isInCart, setIsInCart] = useState(false)

  return (
    <div className="card card-hover group">
      {/* Image Container */}
      <div className="relative h-48 overflow-hidden bg-gray-200">
        {/* Product image would be here */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Wishlist Button */}
        <button
          onClick={() => setIsLiked(!isLiked)}
          className="absolute top-3 right-3 p-2 bg-white/90 hover:bg-white rounded-full shadow-md transition-colors"
        >
          <Heart 
            size={18} 
            className={isLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'} 
          />
        </button>

        {/* Quick Add to Cart */}
        <button
          onClick={() => setIsInCart(true)}
          className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-blue-700"
        >
          <ShoppingCart size={16} className="inline mr-2" />
          Add to Cart
        </button>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="mb-2">
          <span className="text-xs text-blue-600 font-medium bg-blue-50 px-2 py-1 rounded">
            {product.category}
          </span>
        </div>

        <h3 className="font-semibold mb-2 line-clamp-2 h-12 group-hover:text-blue-600 transition-colors">
          {product.title}
        </h3>

        {/* Rating */}
        <div className="flex items-center mb-3">
          <div className="flex items-center mr-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={14}
                className={i < Math.floor(product.rating) 
                  ? "text-yellow-400 fill-yellow-400" 
                  : "text-gray-300"
                }
              />
            ))}
          </div>
          <span className="text-sm text-gray-600">
            {product.rating} ({product.reviews.toLocaleString()})
          </span>
        </div>

        {/* Price and Action */}
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">Price</div>
            <div className="text-2xl font-bold text-green-600">
              ${product.price.toFixed(2)}
            </div>
          </div>

          <button
            onClick={() => setIsInCart(true)}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              isInCart 
                ? 'bg-green-100 text-green-700 border border-green-200'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isInCart ? (
              <>
                <ShoppingCart size={16} className="mr-2" />
                Added
              </>
            ) : (
              <>
                <ShoppingCart size={16} className="mr-2" />
                Add to Cart
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}

export default ProductCard
