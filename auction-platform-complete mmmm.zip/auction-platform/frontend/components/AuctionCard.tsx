\'use client\';

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Clock, Users, TrendingUp, Eye } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface AuctionCardProps {
  auction: {
    id: string
    title: string
    currentPrice: number
    startingPrice: number
    endTime: string
    imageUrl: string
    category: string
    bidCount: number
    watchers: number
  }
}

const AuctionCard = ({ auction }: AuctionCardProps) => {
  const [timeLeft, setTimeLeft] = useState('')
  const [isEndingSoon, setIsEndingSoon] = useState(false)

  useEffect(() => {
    const updateTimer = () => {
      const end = new Date(auction.endTime)
      const now = new Date()
      const diff = end.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft('Ended')
        setIsEndingSoon(false)
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

      if (hours < 1) {
        setTimeLeft(`${minutes}m`)
        setIsEndingSoon(true)
      } else if (hours < 24) {
        setTimeLeft(`${hours}h ${minutes}m`)
        setIsEndingSoon(hours < 3)
      } else {
        const days = Math.floor(hours / 24)
        setTimeLeft(`${days}d`)
        setIsEndingSoon(false)
      }
    }

    updateTimer()
    const interval = setInterval(updateTimer, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [auction.endTime])

  const priceIncrease = ((auction.currentPrice - auction.startingPrice) / auction.startingPrice) * 100

  return (
    <Link href={`/auctions/${auction.id}`}>
      <div className="card card-hover group">
        {/* Image Container */}
        <div className="relative h-48 overflow-hidden bg-gray-200">
          {/* Image would be here */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Auction Status Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            <span className="badge badge-danger px-3 py-1.5 font-semibold">
              🔴 LIVE
            </span>
            {isEndingSoon && (
              <span className="badge badge-warning px-3 py-1.5 font-semibold animate-pulse">
                ENDING SOON
              </span>
            )}
          </div>

          {/* Category */}
          <div className="absolute top-3 right-3">
            <span className="badge badge-info px-3 py-1.5">
              {auction.category}
            </span>
          </div>

          {/* Watchers */}
          <div className="absolute bottom-3 left-3">
            <div className="flex items-center text-white text-sm">
              <Eye size={14} className="mr-1" />
              {auction.watchers.toLocaleString()} watching
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-semibold text-lg mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
            {auction.title}
          </h3>

          {/* Price Section */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-500">Current Bid</span>
              <div className="flex items-center text-green-600 text-sm">
                <TrendingUp size={14} className="mr-1" />
                +{priceIncrease.toFixed(1)}%
              </div>
            </div>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold">${auction.currentPrice.toLocaleString()}</span>
              <span className="text-sm text-gray-500 ml-2 line-through">
                ${auction.startingPrice.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Stats and Timer */}
          <div className="flex items-center justify-between pt-3 border-t border-gray-100">
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-gray-600">
                <Users size={16} className="mr-1.5" />
                <span className="text-sm">{auction.bidCount} bids</span>
              </div>
              <div className={`flex items-center ${isEndingSoon ? 'text-red-600' : 'text-gray-600'}`}>
                <Clock size={16} className="mr-1.5" />
                <span className={`text-sm font-semibold ${isEndingSoon ? 'animate-pulse' : ''}`}>
                  {timeLeft}
                </span>
              </div>
            </div>

            <button className="btn-primary px-4 py-1.5 text-sm">
              Bid Now
            </button>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default AuctionCard
