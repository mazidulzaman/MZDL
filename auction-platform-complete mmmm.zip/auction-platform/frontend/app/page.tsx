\'use client\';

import { useState, useEffect } from 'react'
import AuctionCard from '@/components/AuctionCard'
import ProductCard from '@/components/ProductCard'
import CategoryCard from '@/components/CategoryCard'
import { 
  TrendingUp, Clock, Award, Shield, 
  Truck, CreditCard, Users, Zap 
} from 'lucide-react'

const HomePage = () => {
  const [liveAuctions, setLiveAuctions] = useState([
    {
      id: '1',
      title: 'iPhone 15 Pro Max 256GB',
      currentPrice: 1050,
      startingPrice: 800,
      endTime: '2024-01-20T15:30:00Z',
      imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569',
      category: 'Electronics',
      bidCount: 42,
      watchers: 128
    },
    {
      id: '2',
      title: 'Vintage Rolex Submariner',
      currentPrice: 12500,
      startingPrice: 10000,
      endTime: '2024-01-20T18:45:00Z',
      imageUrl: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3',
      category: 'Watches',
      bidCount: 89,
      watchers: 256
    },
    {
      id: '3',
      title: 'Limited Edition Nike Air Jordans',
      currentPrice: 850,
      startingPrice: 500,
      endTime: '2024-01-20T16:15:00Z',
      imageUrl: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa',
      category: 'Sneakers',
      bidCount: 156,
      watchers: 420
    },
    {
      id: '4',
      title: 'Canon EOS R5 Camera',
      currentPrice: 3200,
      startingPrice: 2800,
      endTime: '2024-01-20T20:30:00Z',
      imageUrl: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd',
      category: 'Photography',
      bidCount: 67,
      watchers: 189
    }
  ])

  const [featuredProducts, setFeaturedProducts] = useState([
    {
      id: '101',
      title: 'Wireless Noise Cancelling Headphones',
      price: 299.99,
      rating: 4.8,
      reviews: 124,
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
      category: 'Audio'
    },
    {
      id: '102',
      title: 'Professional Drone with 4K Camera',
      price: 899.99,
      rating: 4.6,
      reviews: 89,
      imageUrl: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f',
      category: 'Drones'
    },
    {
      id: '103',
      title: 'Designer Leather Handbag',
      price: 450.00,
      rating: 4.9,
      reviews: 234,
      imageUrl: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3',
      category: 'Fashion'
    },
    {
      id: '104',
      title: 'Smart Home Security System',
      price: 349.99,
      rating: 4.7,
      reviews: 156,
      imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64',
      category: 'Home'
    }
  ])

  const [categories, setCategories] = useState([
    { id: 'electronics', name: 'Electronics', icon: '💻', itemCount: 1245 },
    { id: 'fashion', name: 'Fashion', icon: '👕', itemCount: 876 },
    { id: 'art', name: 'Art & Collectibles', icon: '🎨', itemCount: 543 },
    { id: 'home', name: 'Home & Garden', icon: '🏠', itemCount: 987 },
    { id: 'vehicles', name: 'Vehicles', icon: '🚗', itemCount: 234 },
    { id: 'jewelry', name: 'Jewelry', icon: '💎', itemCount: 456 }
  ])

  const [stats, setStats] = useState({
    activeAuctions: 1245,
    totalUsers: 54321,
    itemsSold: 89234,
    totalValue: '$12.5M'
  })

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative container mx-auto px-4 py-24">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Bid, Buy & Win in 
              <span className="block text-yellow-300">Real-Time Auctions</span>
            </h1>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of buyers and sellers in the world's most exciting 
              live auction marketplace. Unique items, amazing deals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="btn-primary text-lg px-8 py-4 flex items-center justify-center">
                <Zap className="mr-2" />
                Start Bidding Now
              </button>
              <button className="bg-white/10 hover:bg-white/20 text-white text-lg px-8 py-4 rounded-lg border-2 border-white/30 transition-colors">
                How It Works →
              </button>
            </div>
          </div>
        </div>

        {/* Wave divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffffff" fillOpacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
          </svg>
        </div>
      </section>

