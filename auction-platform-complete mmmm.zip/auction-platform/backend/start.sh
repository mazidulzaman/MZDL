#!/bin/bash

echo "🚀 Starting Auction Platform Backend..."

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  Warning: .env file not found"
    echo "Creating .env from template..."
    cp .env.example .env
    echo "Please edit .env file with your configuration"
fi

# Start the server
echo "🔥 Starting server..."
npm run dev
