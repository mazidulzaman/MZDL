const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');
const { Pool } = require('pg');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true
}));
app.use(express.json());

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Test database connection
pool.connect()
  .then(() => console.log('✅ Database connected'))
  .catch(err => console.error('❌ Database connection error:', err));

// Store active auctions in memory (for real-time updates)
const activeAuctions = new Map();

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Auction API is running' });
});

// Get all active auctions
app.get('/api/auctions', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        a.id, 
        a.title, 
        a.description, 
        a.current_price as "currentPrice",
        a.starting_price as "startingPrice",
        a.end_time as "endTime",
        a.image_url as "imageUrl",
        a.category,
        a.seller_id as "sellerId",
        COUNT(b.id) as "bidCount",
        (SELECT COUNT(*) FROM auction_watches aw WHERE aw.auction_id = a.id) as "watchers"
      FROM auctions a
      LEFT JOIN bids b ON a.id = b.auction_id
      WHERE a.status = 'active' 
        AND a.end_time > NOW()
      GROUP BY a.id
      ORDER BY a.end_time ASC
      LIMIT 20
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching auctions:', error);
    res.status(500).json({ error: 'Failed to fetch auctions' });
  }
});

// Get single auction
app.get('/api/auctions/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const auctionResult = await pool.query(`
      SELECT 
        a.*,
        u.username as "sellerName",
        u.rating as "sellerRating"
      FROM auctions a
      LEFT JOIN users u ON a.seller_id = u.id
      WHERE a.id = $1
    `, [id]);

    if (auctionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Auction not found' });
    }

    const bidsResult = await pool.query(`
      SELECT 
        b.id,
        b.amount,
        b.created_at as "createdAt",
        u.username as "bidderName",
        u.id as "bidderId"
      FROM bids b
      LEFT JOIN users u ON b.bidder_id = u.id
      WHERE b.auction_id = $1
      ORDER BY b.amount DESC
      LIMIT 20
    `, [id]);

    res.json({
      ...auctionResult.rows[0],
      bids: bidsResult.rows
    });
  } catch (error) {
    console.error('Error fetching auction:', error);
    res.status(500).json({ error: 'Failed to fetch auction' });
  }
});

// Place a bid
app.post('/api/auctions/:id/bid', async (req, res) => {
  try {
    const { id } = req.params;
    const { amount, userId } = req.body;

    // Start transaction
    await pool.query('BEGIN');

    // Get auction details
    const auctionResult = await pool.query(`
      SELECT current_price, starting_price, end_time, status
      FROM auctions 
      WHERE id = $1 FOR UPDATE
    `, [id]);

    if (auctionResult.rows.length === 0) {
      await pool.query('ROLLBACK');
      return res.status(404).json({ error: 'Auction not found' });
    }

    const auction = auctionResult.rows[0];

    // Validate bid
    if (auction.status !== 'active') {
      await pool.query('ROLLBACK');
      return res.status(400).json({ error: 'Auction is not active' });
    }

    if (new Date(auction.end_time) < new Date()) {
      await pool.query('ROLLBACK');
      return res.status(400).json({ error: 'Auction has ended' });
    }

    if (amount <= auction.current_price) {
      await pool.query('ROLLBACK');
      return res.status(400).json({ 
        error: `Bid must be higher than current price ($${auction.current_price})` 
      });
    }

    // Update auction
    await pool.query(
      'UPDATE auctions SET current_price = $1 WHERE id = $2',
      [amount, id]
    );

    // Record bid
    const bidId = uuidv4();
    await pool.query(
      'INSERT INTO bids (id, auction_id, bidder_id, amount) VALUES ($1, $2, $3, $4)',
      [bidId, id, userId, amount]
    );

    await pool.query('COMMIT');

    // Broadcast to all connected clients
    io.to(`auction:${id}`).emit('new-bid', {
      id: bidId,
      amount,
      userId,
      timestamp: new Date().toISOString()
    });

    res.json({ 
      success: true, 
      message: 'Bid placed successfully',
      newPrice: amount 
    });

  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Error placing bid:', error);
    res.status(500).json({ error: 'Failed to place bid' });
  }
});

// WebSocket Connection
io.on('connection', (socket) => {
  console.log('🔌 New client connected:', socket.id);

  // Join auction room
  socket.on('join-auction', (auctionId) => {
    socket.join(`auction:${auctionId}`);
    console.log(`Client ${socket.id} joined auction ${auctionId}`);

    // Send current auction state
    const auction = activeAuctions.get(auctionId);
    if (auction) {
      socket.emit('auction-state', auction);
    }
  });

  // Leave auction room
  socket.on('leave-auction', (auctionId) => {
    socket.leave(`auction:${auctionId}`);
  });

  // Handle bid via WebSocket
  socket.on('place-bid', async (data) => {
    const { auctionId, userId, amount } = data;

    try {
      // Update auction in memory
      const auction = activeAuctions.get(auctionId);
      if (auction && amount > auction.currentPrice) {
        auction.currentPrice = amount;
        auction.lastBidder = userId;
        auction.lastBidTime = new Date();
        activeAuctions.set(auctionId, auction);
      }

      // Broadcast to room
      io.to(`auction:${auctionId}`).emit('bid-update', {
        userId,
        amount,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error('WebSocket bid error:', error);
      socket.emit('bid-error', { error: 'Failed to process bid' });
    }
  });

  // Disconnect
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Load active auctions into memory
async function loadActiveAuctions() {
  try {
    const result = await pool.query(`
      SELECT id, current_price as "currentPrice", end_time as "endTime"
      FROM auctions 
      WHERE status = 'active' AND end_time > NOW()
    `);

    result.rows.forEach(auction => {
      activeAuctions.set(auction.id, {
        currentPrice: auction.currentPrice,
        endTime: auction.endTime,
        lastBidder: null,
        lastBidTime: null
      });
    });

    console.log(`📊 Loaded ${activeAuctions.size} active auctions`);
  } catch (error) {
    console.error('Error loading auctions:', error);
  }
}

// Auction expiration checker
setInterval(async () => {
  try {
    const now = new Date();
    const expiredAuctions = [];

    for (const [auctionId, auction] of activeAuctions.entries()) {
      if (new Date(auction.endTime) < now) {
        expiredAuctions.push(auctionId);

        // Notify clients
        io.to(`auction:${auctionId}`).emit('auction-ended', {
          auctionId,
          winner: auction.lastBidder,
          finalPrice: auction.currentPrice,
          timestamp: now.toISOString()
        });
      }
    }

    // Remove expired auctions
    expiredAuctions.forEach(id => activeAuctions.delete(id));

    if (expiredAuctions.length > 0) {
      console.log(`⏰ Ended ${expiredAuctions.length} auctions`);
    }

  } catch (error) {
    console.error('Error checking auction expiration:', error);
  }
}, 10000); // Check every 10 seconds

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}`);

  // Load initial data
  await loadActiveAuctions();
});

// Error handling
process.on('unhandledRejection', (error) => {
  console.error('Unhandled Rejection:', error);
});

module.exports = { app, server, io };
